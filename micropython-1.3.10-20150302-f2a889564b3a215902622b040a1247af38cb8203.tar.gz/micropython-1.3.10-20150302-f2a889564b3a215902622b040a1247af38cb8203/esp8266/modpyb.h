extern const mp_obj_type_t pyb_pin_type;
